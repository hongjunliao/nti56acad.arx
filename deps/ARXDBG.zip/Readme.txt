ARXDBG sample Readme.txt

Copyright 2017 Autodesk, Inc.  All rights reserved.

Use of this software is subject to the terms of the Autodesk license 
agreement provided at the time of installation or download, or which 
otherwise accompanies this software in either electronic or hard copy form.   

This application is provided to help in debugging and understanding 
ObjectARX applications. The application serves as a 
learning/debugging tool by allowing the user to monitor what types 
of events are happening in the system. There is an extensive Word 
document that describes this application's capabilities in great 
detail.

Please read the 'ArxDbg.doc' for more details.